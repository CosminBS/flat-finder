export const dummyData = [
    {
    name: 'Chirie 1',
    city: 'Cluj',
    strName: 'Principala',
    strNumber: 12,
    areaSize: 64,
    AC: 'Yes',
    yearBuilt: 1993,
    rentPrice: 450,
    dateAvailable: "24-04-2024",
    pName: 'John Doe',
    pEmail: 'mail@mail.com',
    url:'../../src/assets/cladire-1.jpg'
    },

    {
    name: 'Chirie 2',
    city: 'Cluj',
    strName: 'Principala',
    strNumber: 12,
    areaSize: 64,
    AC: 'Yes',
    yearBuilt: 1993,
    rentPrice: 450,
    dateAvailable: "24-04-2024",
    pName: 'John Doe',
    pEmail: 'mail@mail.com',
    url:'../../src/assets/cladire-2.jpg'
    },

    {
    name: 'Chirie 3',
    city: 'Sibiu',
    strName: 'Principala',
    strNumber: 12,
    areaSize: 64,
    AC: 'Yes',
    yearBuilt: 1993,
    rentPrice: 450,
    dateAvailable: "24-04-2024",
    pName: 'John Doe',
    pEmail: 'mail@mail.com',
    url:'../../src/assets/cladire-3.jpg'
    },

    {
    name: 'Chirie 2',
    city: 'Cluj',
    strName: 'Principala',
    strNumber: 12,
    areaSize: 64,
    AC: 'Yes',
    yearBuilt: 1993,
    rentPrice: 450,
    dateAvailable: "24-04-2024",
    pName: 'John Doe',
    pEmail: 'mail@mail.com',
    url:'../../src/assets/cladire-2.jpg'
    },
]